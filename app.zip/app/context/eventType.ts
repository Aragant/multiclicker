

export class EventType {
    static LOGIN = "login";
    static CLICK = "click";
    static CLICKED = "clicked";
    static SET_GAME_INFO = "SET_GAME_INFO";
}
