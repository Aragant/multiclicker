

export class EventType {
    static LOGIN = "login";
    static CLICK = "click";
    static CLICKED = "clicked";
    static GET_GAME_INFO = "GET_GAME_INFO";
}
