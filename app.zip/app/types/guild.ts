export interface Guild {
    id: string;
    name: string;
    description : string;
    sum_members: number;
    members: string[];
}