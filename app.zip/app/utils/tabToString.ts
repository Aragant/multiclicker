export function tabToString(tab: string[]): string {
    return tab.join(","); 
}